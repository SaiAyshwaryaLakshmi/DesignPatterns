package strategyPattern.returnCash;

public abstract class ReturnCash {

	public abstract void returnCash();
}
