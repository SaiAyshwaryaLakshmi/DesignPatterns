package strategyPattern.pumpGasUnit;

public abstract class PumpGasUnit {

	public abstract void UnitOfGasPumped();
}
