package strategyPattern.payMsg;

public abstract class PayMsg {

	public abstract void Pay();
}
