package strategyPattern.payMsg;

public class PayMsg1 extends PayMsg {

	/* (non-Javadoc)
	 * @see strategyPattern.payMsg.PayMsg#PayMessage()
	 */
	
	public void Pay() {
		// TODO Auto-generated method stub
		//Displays the menu for Payment Options for GasPump1
		
		System.out.println("Please Select from the following Options");
		System.out.println("2.Credit Card ");
		System.out.println("4.Debit Card");
		
	}

	/* (non-Javadoc)
	 * @see strategyPattern.payMsg.PayMsg#PayMessage()
	 */
	

	
	
}
