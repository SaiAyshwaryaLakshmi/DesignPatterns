package strategyPattern.displayMenu;

public class DisplayMenu2 extends DisplayMenu {

	/* (non-Javadoc)
	 * @see strategyPattern.displayMenu.DisplayMenu#displayMenu()
	 */
	@Override
	public void displayMenu() {
		// TODO Auto-generated method stub
		System.out.println("Please Select One of the Options to Begin");
		System.out.println("0.Regular Gasoline");
		System.out.println("1.Super Gasoline");
		System.out.println("2.Premium Gasoline");
		
	}

}
