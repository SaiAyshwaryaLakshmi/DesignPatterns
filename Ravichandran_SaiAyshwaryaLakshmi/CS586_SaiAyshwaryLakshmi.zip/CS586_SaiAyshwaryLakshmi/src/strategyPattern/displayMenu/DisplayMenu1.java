package strategyPattern.displayMenu;

public class DisplayMenu1 extends DisplayMenu {

	/* (non-Javadoc)
	 * @see strategyPattern.displayMenu.DisplayMenu#displayMenu()
	 */
	@Override
	public void displayMenu() {
		// TODO Auto-generated method stub
		System.out.println("Please Select One of the Options to Begin");
		System.out.println("0.Regular Gas");
		System.out.println("1.Diesel");
	}

	
}
