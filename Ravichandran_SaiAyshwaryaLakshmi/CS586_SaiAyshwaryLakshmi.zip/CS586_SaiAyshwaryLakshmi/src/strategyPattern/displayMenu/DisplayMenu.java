package strategyPattern.displayMenu;

public abstract class DisplayMenu {

	public abstract void displayMenu();
}
