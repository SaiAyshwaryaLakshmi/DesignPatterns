package strategyPattern.initializeData;

public abstract class InitializeData {

	public abstract void initializeData();
}
