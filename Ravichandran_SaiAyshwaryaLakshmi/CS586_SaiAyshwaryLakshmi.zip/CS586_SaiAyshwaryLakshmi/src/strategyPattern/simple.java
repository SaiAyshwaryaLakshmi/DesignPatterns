/**
 * 
 */
package strategyPattern;

/**
 * @author 
 *
 */
public class simple {

}
