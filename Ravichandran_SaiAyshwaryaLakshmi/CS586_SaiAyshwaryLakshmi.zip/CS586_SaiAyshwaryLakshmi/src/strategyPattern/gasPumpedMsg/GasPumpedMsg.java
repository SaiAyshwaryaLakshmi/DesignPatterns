package strategyPattern.gasPumpedMsg;

public abstract class GasPumpedMsg {

	public abstract void gasPumpedMsg();
}
