package strategyPattern.wrongPinMsg;

public class WrongPinMsg1 extends WrongPinMsg {

	/* (non-Javadoc)
	 * @see strategyPattern.wrongPinMsg.WrongPinMsg#wrongPinMsg()
	 */
	@Override
	public void wrongPinMsg() {
		// TODO Auto-generated method stub
		System.out.println("The Pin entered is Incorrect");
	}

}
