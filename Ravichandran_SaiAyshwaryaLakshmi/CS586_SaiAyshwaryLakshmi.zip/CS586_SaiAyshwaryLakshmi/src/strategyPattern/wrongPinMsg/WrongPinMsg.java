package strategyPattern.wrongPinMsg;

public abstract class WrongPinMsg {

	public abstract void wrongPinMsg();
}
