package strategyPattern.setInitialValues;

public abstract class SetInitialValues {

	public abstract void storeInitialValues();
}
