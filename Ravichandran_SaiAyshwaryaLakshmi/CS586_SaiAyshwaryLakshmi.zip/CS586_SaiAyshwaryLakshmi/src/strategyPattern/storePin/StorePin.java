/**
 * 
 */
package strategyPattern.storePin;

/**
 * @author ayshw
 *
 */
public abstract class StorePin {

	public abstract void storePin();
}
