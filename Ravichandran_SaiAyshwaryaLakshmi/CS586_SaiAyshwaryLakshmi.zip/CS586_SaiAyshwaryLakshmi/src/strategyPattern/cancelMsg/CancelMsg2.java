package strategyPattern.cancelMsg;

public class CancelMsg2 extends CancelMsg {

	/* (non-Javadoc)
	 * @see strategyPattern.cancelMsg.CancelMsg#cancelMsg()
	 */
	@Override
	public void cancelMsg() {
		// TODO Auto-generated method stub
		System.out.println("Operation Cancelled ,  Start to begin, pump is Active");
		
	}

}
