package strategyPattern.cancelMsg;

public abstract class CancelMsg {

	public abstract void cancelMsg();
}
