package strategyPattern.stopMsg;

public class StopMsg2 extends StopMsg{

	/* (non-Javadoc)
	 * @see strategyPattern.stopMsg.StopMsg#stopMsg()
	 */
	@Override
	public void stopMsg() {
		// TODO Auto-generated method stub
		System.out.println("Pumping has Stopped,Would you like a Receipt?"); 
		
	}

}
