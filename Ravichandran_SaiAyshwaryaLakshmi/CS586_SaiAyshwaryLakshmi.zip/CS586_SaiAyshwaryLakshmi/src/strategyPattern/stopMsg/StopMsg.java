package strategyPattern.stopMsg;

public abstract class StopMsg {
	
	public abstract void stopMsg();

}
