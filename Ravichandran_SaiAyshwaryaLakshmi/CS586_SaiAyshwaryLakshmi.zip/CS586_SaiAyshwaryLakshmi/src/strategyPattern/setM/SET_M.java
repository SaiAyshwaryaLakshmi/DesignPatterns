/**
 * 
 */
package strategyPattern.setM;



/**
 * @author ayshw
 *
 */
public abstract class SET_M {
	
	public abstract void setValueM(int value);


}
