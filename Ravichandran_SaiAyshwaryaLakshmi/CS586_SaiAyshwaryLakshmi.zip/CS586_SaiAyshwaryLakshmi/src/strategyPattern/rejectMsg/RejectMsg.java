package strategyPattern.rejectMsg;

public abstract class RejectMsg {

	public abstract void rejectMsg();
}
