package strategyPattern.readyMsg;

public abstract class ReadyMsg {

	public abstract void readyMsg();
}
