package strategyPattern.readyMsg;

public class ReadyMsg1 extends ReadyMsg {

	/* (non-Javadoc)
	 * @see strategyPattern.readyMsg.ReadyMsg#readyMsg()
	 */
	@Override
	public void readyMsg() {
		// TODO Auto-generated method stub
		
		System.out.println("Gas Pump is Ready to Pump Diesel or Regular Gas"); //ReadyMessage for Gas Pump1
	}

}
