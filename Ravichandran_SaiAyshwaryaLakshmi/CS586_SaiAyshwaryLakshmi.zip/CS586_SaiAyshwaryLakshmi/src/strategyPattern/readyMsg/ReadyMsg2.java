package strategyPattern.readyMsg;

public class ReadyMsg2 extends ReadyMsg {

	/* (non-Javadoc)
	 * @see strategyPattern.readyMsg.ReadyMsg#readyMsg()
	 */
	@Override
	public void readyMsg() {
		// TODO Auto-generated method stub
		
		System.out.println("Gas Pump is Ready to Premium Gas or Regular Gas or Super Gas"); //ReadyMessage for Gas Pump2
	}

}
