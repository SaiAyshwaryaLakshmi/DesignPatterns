package strategyPattern.storeCash;

public abstract class StoreCash {
	
	public abstract void acceptCash();

}
