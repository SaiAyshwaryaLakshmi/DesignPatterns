package strategyPattern.storePrice;

public abstract class StorePrice {

	public abstract void storeGasPrices();
}
