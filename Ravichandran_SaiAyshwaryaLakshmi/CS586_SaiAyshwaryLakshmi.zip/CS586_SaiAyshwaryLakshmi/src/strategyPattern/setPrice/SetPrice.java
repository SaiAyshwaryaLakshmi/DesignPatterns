package strategyPattern.setPrice;

public abstract class SetPrice {
	
	public abstract void setPrice(int gasType);

}
