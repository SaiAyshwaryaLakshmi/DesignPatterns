package strategyPattern.enterPin;

public class EnterPin1 extends EnterPin{

	/* (non-Javadoc)
	 * @see strategyPattern.enterPin.EnterPin#enterPin()
	 */
	@Override
	public void enterPin() {
		// TODO Auto-generated method stub
		
		System.out.println("Please Enter your 4 digit Pin Number");
	}

}
