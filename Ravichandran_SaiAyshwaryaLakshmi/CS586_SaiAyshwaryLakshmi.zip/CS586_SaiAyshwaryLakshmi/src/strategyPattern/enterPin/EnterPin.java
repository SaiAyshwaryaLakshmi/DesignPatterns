package strategyPattern.enterPin;

public abstract class EnterPin {

	public abstract void enterPin();
}
