package strategyPattern.printReceipt;

public abstract class PrintReceipt {
	
	public abstract void printReceipt();

}
